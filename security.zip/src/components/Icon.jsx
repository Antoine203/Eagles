import React from "react";
import CopyrightIcon from '@material-ui/icons/Copyright';

function Icon(){
    return(
        <span><CopyrightIcon/></span>
    )
}

export default Icon;